const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json()); // Parse JSON data

// Simulated cart data
let cart = [];

// Add an item to the cart
app.post('/add-to-cart', (req, res) => {
    const { id, name, price, image } = req.body;
    cart.push({ id, name, price, image });
    res.json({ message: 'Item added to the cart', cart });
});

// Get all cart items
app.get('/cart', (req, res) => {
    res.json(cart);
});

// Clear the cart (optional for testing)
app.post('/clear-cart', (req, res) => {
    cart = [];
    res.json({ message: 'Cart cleared', cart });
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Backend running at http://localhost:${PORT}`);
});
